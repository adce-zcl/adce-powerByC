class Login
{
private:
    int id;
    string name;
    string passwd;
    int type;

public:
    bool log(string _name, string _passwd)
    {
        // 1. 验证输入是否合法
        // 2. 传入数据库
        // 3. 接收结果是否为null
        // 4. isNULL return false
        // 5. 不为空  return true
        // 6. type = value.type
    }

};