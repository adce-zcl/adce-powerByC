class back
{
private:
    int tk_id;
public:
    bool back_tk()
    {
        // 1.id对应的表项nums+1
        // 2.删除buy表的一项
        // 3.返回true
    }
};
