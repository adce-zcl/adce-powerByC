class Tick
{
private:
    int tk_id;
    int user_id;

public:

    bool get_tick(int _tk_id)
    {
        // 1.验证tk_id到数据库
        // 2.验证nums 是否 == 0
        // 3.if == 0， reutrn false
        // 4.if != 0, nums--, reutrn true
    }
};