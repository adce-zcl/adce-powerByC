class Search
{
private:
    int flight_id;
public:
    void search_flight()
    {
        // 1.通过id找到对应的航班信息
        // 2.返回航班信息
        // 3.显示list
    }
};