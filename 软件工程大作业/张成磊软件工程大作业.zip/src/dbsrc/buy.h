class buy
{
private:
    int name_id;
    int ticked_id;
public:
    int get_name_id()
    {
        return name_id;
    }
    int get_ticked_id()
    {
        return ticked_id;
    }
    void set_name_id(int id)
    {
        name_id = id;
    }
    void set_ticked_id(int id)
    {
        ticked_id = id;
    }
};
