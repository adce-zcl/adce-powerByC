class List
{
public:
    void get_list()
    {
        // 1.检索buy表
        // 2.返回所有的表项
        // 3.生成list
    }
};